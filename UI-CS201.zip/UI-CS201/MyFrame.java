
import javax.swing.JFrame;
public class MyFrame extends JFrame
{
    
    public MyFrame(){
        
       setSize(640,400);
       setLocation(500,300);
       setTitle("Nathaniel Marin, CS-201");
       setVisible(true);
    }
    public static void main(String[] args){
        new MyFrame();
    }
}

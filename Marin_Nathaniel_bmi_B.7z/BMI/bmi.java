
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class bmi extends JFrame
{
    JLabel hLabel = new JLabel();
    JLabel wLabel = new JLabel();
    JLabel bmiLabel = new JLabel();
    JLabel iLabel = new JLabel();
    JLabel pLabel = new JLabel();
    
    JButton compBut = new JButton();
    JButton exitBut = new JButton();
    
    JTextField hTxtFld = new JTextField();
    JTextField wTxtFld = new JTextField();
    JTextField bmiTxtFld = new JTextField();
    
    double hTxt;
    double wTxt;
    
    
    public bmi(){
        
        setTitle("BMI Calculator");
        setSize(500,300);
        
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
            
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "Exited program", "Exit",JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        });
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints grid = new GridBagConstraints();
        
        
        hLabel.setText("Height:");
        grid.gridx = 0;
        grid.gridy = 0;
        getContentPane().add(hLabel, grid);
        
        wLabel.setText("Weight:");
        grid.gridx = 0;
        grid.gridy = 1;
        getContentPane().add(wLabel, grid);
        
        bmiLabel.setText("BMI:");
        grid.gridx = 0;
        grid.gridy = 2;
        getContentPane().add(bmiLabel, grid);
        
        iLabel.setText("inches");
        grid.gridx = 2;
        grid.gridy = 0;
        getContentPane().add(iLabel, grid);
        
        pLabel.setText("pounds");
        grid.gridx = 2;
        grid.gridy = 1;
        getContentPane().add(pLabel, grid);
        
        compBut.setText("Compute BMI");
        grid.gridx = 0;
        grid.gridy = 3;
        getContentPane().add(compBut, grid);
        
        compBut.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                hTxt = Double.parseDouble(hTxtFld.getText());
                wTxt = Double.parseDouble(wTxtFld.getText());
                double comp = (wTxt / (hTxt * hTxt))*703;
                bmiTxtFld.setText(String.format("%.2f",comp));
                
                
                
            }
        });
        
        
        exitBut.setText("Exit");
        grid.gridx = 2;
        grid.gridy = 3;
        getContentPane().add(exitBut, grid);
        
        exitBut.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "Exited program", "Exit",JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        });
        
        hTxtFld.setColumns(4);
        grid.gridx = 1;
        grid.gridy = 0;
        getContentPane().add(hTxtFld, grid);
        
        wTxtFld.setColumns(4);
        grid.gridx = 1;
        grid.gridy = 1;
        getContentPane().add(wTxtFld, grid);
        
        bmiTxtFld.setColumns(5);
        grid.gridx = 1;
        grid.gridy = 2;
        getContentPane().add(bmiTxtFld, grid);
        
        
    }

    public static void main(String args[]){
        new bmi().show();
        
    }
}
